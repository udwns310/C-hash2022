﻿namespace MyPhoneBook
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.closeButton = new System.Windows.Forms.Button();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.findButton = new System.Windows.Forms.Button();
            this.findTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textViewBox = new System.Windows.Forms.TextBox();
            this.loadFile = new System.Windows.Forms.Button();
            this.inputFinish = new System.Windows.Forms.Button();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(637, 281);
            this.closeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(99, 42);
            this.closeButton.TabIndex = 25;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // resultTextBox
            // 
            this.resultTextBox.Location = new System.Drawing.Point(431, 69);
            this.resultTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.resultTextBox.Multiline = true;
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.ReadOnly = true;
            this.resultTextBox.Size = new System.Drawing.Size(303, 159);
            this.resultTextBox.TabIndex = 24;
            // 
            // findButton
            // 
            this.findButton.Location = new System.Drawing.Point(650, 15);
            this.findButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.findButton.Name = "findButton";
            this.findButton.Size = new System.Drawing.Size(86, 30);
            this.findButton.TabIndex = 23;
            this.findButton.Text = "찾기";
            this.findButton.UseVisualStyleBackColor = true;
            this.findButton.Click += new System.EventHandler(this.findButton_Click);
            // 
            // findTextBox
            // 
            this.findTextBox.Location = new System.Drawing.Point(530, 19);
            this.findTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.findTextBox.Name = "findTextBox";
            this.findTextBox.Size = new System.Drawing.Size(113, 25);
            this.findTextBox.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(449, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 21;
            this.label3.Text = "찾을 번호: ";
            // 
            // textViewBox
            // 
            this.textViewBox.Location = new System.Drawing.Point(15, 114);
            this.textViewBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textViewBox.Multiline = true;
            this.textViewBox.Name = "textViewBox";
            this.textViewBox.ReadOnly = true;
            this.textViewBox.Size = new System.Drawing.Size(393, 159);
            this.textViewBox.TabIndex = 20;
            // 
            // loadFile
            // 
            this.loadFile.Location = new System.Drawing.Point(175, 281);
            this.loadFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.loadFile.Name = "loadFile";
            this.loadFile.Size = new System.Drawing.Size(233, 42);
            this.loadFile.TabIndex = 19;
            this.loadFile.Text = "CSV File Load";
            this.loadFile.UseVisualStyleBackColor = true;
            this.loadFile.Click += new System.EventHandler(this.loadFile_Click);
            // 
            // inputFinish
            // 
            this.inputFinish.Location = new System.Drawing.Point(322, 22);
            this.inputFinish.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.inputFinish.Name = "inputFinish";
            this.inputFinish.Size = new System.Drawing.Size(86, 72);
            this.inputFinish.TabIndex = 18;
            this.inputFinish.Text = "입력 완료";
            this.inputFinish.UseVisualStyleBackColor = true;
            this.inputFinish.Click += new System.EventHandler(this.inputFinish_Click);
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(93, 69);
            this.phoneTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(204, 25);
            this.phoneTextBox.TabIndex = 17;
            this.phoneTextBox.Text = "010-0000-0000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "전화번호 :";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(93, 22);
            this.nameTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(204, 25);
            this.nameTextBox.TabIndex = 15;
            this.nameTextBox.Text = "최영준";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "이름: ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 352);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.resultTextBox);
            this.Controls.Add(this.findButton);
            this.Controls.Add(this.findTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textViewBox);
            this.Controls.Add(this.loadFile);
            this.Controls.Add(this.inputFinish);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "전화번호 관리[최영준]";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.Button findButton;
        private System.Windows.Forms.TextBox findTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textViewBox;
        private System.Windows.Forms.Button loadFile;
        private System.Windows.Forms.Button inputFinish;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

