﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPhoneBook
{
    public partial class Form1 : Form
    {               
        PhoneBook myPhoneBook;
        public Form1()
        {
            InitializeComponent();
            myPhoneBook = new PhoneBook();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void inputFinish_Click(object sender, EventArgs e)
        {
            myPhoneBook.AddPhone(nameTextBox.Text, 
                                 phoneTextBox.Text);
            textViewBox.Text = myPhoneBook.LisuUpAll();
        }

        private void loadFile_Click(object sender, EventArgs e)
        {
           // myPhoneBook.ReadCSVFile(
             //   "C:\\Users\\young\\Desktop\\C#2022\\MyPhoneBook\\MyPhoneBook\\phonebook.csv", true);
            openFileDialog1.ShowDialog();
            string fname = openFileDialog1.FileName;
            myPhoneBook.ReadCSVFile(fname, true);
            textViewBox.Text = myPhoneBook.LisuUpAll();
        }

        private void findButton_Click(object sender, EventArgs e)
        {
            List<string> result;
            if (myPhoneBook.FindNameByNumber(findTextBox.Text, out result))
            {
                resultTextBox.Clear();
                foreach (string s in result)
                    resultTextBox.Text += (s + "\r\n");
            }
           

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
