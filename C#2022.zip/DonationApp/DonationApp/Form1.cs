﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DonationApp
{
    public partial class Form1 : Form
    {
        Graphics g;
        Pen pen;
        int nPosX = 0;
        int nPosY = 0;
        bool bMove = false;

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
            pen = new Pen(Color.Black, 3);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            g.Clear(Color.White);
        }

        private void panelMouseDown(object sender, MouseEventArgs e)
        {
            nPosX = e.X;
            nPosY = e.Y;
            bMove = true;

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (bMove)
            {
                g.DrawLine(pen, new Point(nPosX, nPosY), e.Location);
                nPosX = e.X;
                nPosY = e.Y;
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            bMove = false;
        }

        private void amountBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                string str = amountBox.Text;
                string money;
                money = String.Format("{0:#,###}", Convert.ToInt32(str));
                amountBox.Text = money;
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            int money = amountBar.Value;
            amountBox.Text = String.Format("{0: #,###}", money * 10000);
        }
    }
}
